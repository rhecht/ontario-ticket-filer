<?php

// No difference in post and page so just include page file
require_once('popup-page.php');

?>
