<div class="sidebar">
	<?php generated_dynamic_sidebars(1); ?>
</div>				

<!-- End of Content -->
<div class="clear"></div>