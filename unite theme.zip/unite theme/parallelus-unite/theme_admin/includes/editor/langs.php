<?php
$strings = "tinyMCE.addI18n({
	en:{
		theme_shortcode: {
			desc : 'Add a theme specific shortcode'
		},
		theme_contact:{
			desc : 'Add a contact form'
		}
	}
});
";
?>